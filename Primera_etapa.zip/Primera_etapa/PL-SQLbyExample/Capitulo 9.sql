spool C:\Users\mauri\Desktop\Segunda_evaluacion\Salidas\Capitulo9.txt
/*
rem **********************************************************
rem * Elaborado por:                                         *
rem * Taboada Sanchez Mauricio Manuel                        *                 
rem * Realizado el 30 de noviembre  de 2021                  *
rem * ROSENZWEIG,B &  RAKHIMOV,E (2009).                     *
rem *Oracle� PL/SQL�by Example,Boston,MA,USA:Perarson.       *
rem **********************************************************
*/

set colsep '|='
set describe linenum on
SET PAGESIZE 99;
SET LINESIZE 150
alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY';
alter session set NLS_DATE_LANGUAGE = 'ENGLISH';
SET SERVEROUTPUT ON;

/*
In this exercise, you display the number of students for a given zip code. You use nested PL/SQL blocks to achieve the desired results. The original PL/SQL script does not contain any exception handlers. Therefore, you are asked to identify possible errors that may occur and define exception handlers for them.
(ROSENZWEIG &  RAKHIMOV, 2009, 183)
*/


-- ch9_1a.sql, version 1.0

DECLARE
	v_zip VARCHAR2(5) := '&sv_zip';
	v_total NUMBER(1);
-- outer block
BEGIN
	DBMS_OUTPUT.PUT_LINE ('Check if provided zipcode is valid');
	SELECT zip
		INTO v_zip
		FROM zipcode
		WHERE zip = v_zip;
	-- inner block
	BEGIN
		SELECT count(*)
			INTO v_total
			FROM student
			WHERE zip = v_zip;
		DBMS_OUTPUT.PUT_LINE ('There are '||v_total||' students for zipcode '||v_zip);
	END;
	DBMS_OUTPUT.PUT_LINE ('Done...');
END;
.
/

--Correr con 07024
-- Con este valor arroja un error, que indica que el n�mero es demasiado grande.

SELECT count(*)
FROM student
WHERE zip = 07024;

SELECT count(*)
FROM student
WHERE zip = 30342;

--Son 10 estudiantes, por lo tanto v_total debe ser number(2)

-- Agregar exception

DECLARE
	v_zip VARCHAR2(5) := '&sv_zip';
	v_total NUMBER(1);
-- outer block
BEGIN
	DBMS_OUTPUT.PUT_LINE ('Check if provided zipcode is valid');
	SELECT zip
		INTO v_zip
		FROM zipcode
		WHERE zip = v_zip;
	-- inner block
	BEGIN
		SELECT count(*)
			INTO v_total
			FROM student
			WHERE zip = v_zip;
		DBMS_OUTPUT.PUT_LINE ('There are '||v_total||' students for zipcode '||v_zip);
	EXCEPTION
		WHEN VALUE_ERROR OR INVALID_NUMBER THEN
			DBMS_OUTPUT.PUT_LINE ('An error has occurred');
	END;
	DBMS_OUTPUT.PUT_LINE ('Done...');
END;
.
/



DECLARE
	v_zip VARCHAR2(5) := '&sv_zip';
	v_total NUMBER(1);
-- outer block
BEGIN
	DBMS_OUTPUT.PUT_LINE ('Check if provided zipcode is valid');
	SELECT zip
		INTO v_zip
		FROM zipcode
		WHERE zip = v_zip;
	-- inner block
	BEGIN
		SELECT count(*)
			INTO v_total
			FROM student
			WHERE zip = v_zip;
		DBMS_OUTPUT.PUT_LINE ('There are '||v_total||' students for zipcode '||v_zip);
	END;
	DBMS_OUTPUT.PUT_LINE ('Done...');
EXCEPTION
	WHEN VALUE_ERROR OR INVALID_NUMBER THEN
		DBMS_OUTPUT.PUT_LINE ('An error has occurred');
END;
.
/
--Esta es una excepci�n global

SELECT count(student_id), section_id
FROM enrollment
WHERE section_id = 89
group by section_id;

SELECT count(student_id), section_id
FROM enrollment
WHERE section_id = 99
group by section_id;

SELECT count(student_id), section_id
FROM enrollment
WHERE section_id = 100
group by section_id;

DECLARE
	v_section NUMBER := '&sv_section';
	v_total NUMBER(2);
	e_mayor10 EXCEPTION;
-- outer block
BEGIN
	
	SELECT count(student_id)
		INTO v_total
		FROM enrollment
		WHERE section_id = v_section
		group by section_id;
	
	IF v_total>10 THEN
		RAISE e_mayor10;
	ELSE 
		DBMS_OUTPUT.PUT_LINE ('Done...');
	END IF;
EXCEPTION
	WHEN e_mayor10 THEN
		DBMS_OUTPUT.PUT_LINE ('M�s de diez...');
END;
.
/

-- ch9_2a.sql, version 1.0 (ROSENZWEIG y RAKHIMOV, 2009, 193).

DECLARE
    v_instructor_id NUMBER := &sv_instructor_id;
    v_tot_sections NUMBER;
    v_name VARCHAR2(30);
    e_too_many_sections EXCEPTION;
BEGIN
    SELECT COUNT(*)
    INTO v_tot_sections
    FROM section
    WHERE instructor_id = v_instructor_id;
    IF v_tot_sections >= 10 THEN
    RAISE e_too_many_sections;
    ELSE
    SELECT RTRIM(first_name)||' '||RTRIM(last_name)
    INTO v_name
    FROM instructor
    WHERE instructor_id = v_instructor_id;
    DBMS_OUTPUT.PUT_LINE ('Instructor, '||v_name||', teaches '||
    v_tot_sections||' sections');
    END IF;
    EXCEPTION
    WHEN e_too_many_sections THEN
    DBMS_OUTPUT.PUT_LINE ('This instructor teaches too much');
END;
.
/

--Este script podemos ver que las exepciones funcionan correctamente, pero si quisieramos 
--mostar el nombre del instrucor en nuestro mensaje de error, podemos hacerlo de la siguiente forma.

DECLARE
v_instructor_id NUMBER := &sv_instructor_id;
v_tot_sections NUMBER;
v_name VARCHAR2(30);
e_too_many_sections EXCEPTION;
BEGIN
SELECT COUNT(*)
INTO v_tot_sections
FROM section
WHERE instructor_id = v_instructor_id;
SELECT RTRIM(first_name)||' '||RTRIM(last_name)
INTO v_name
FROM instructor
WHERE instructor_id = v_instructor_id;
IF v_tot_sections >= 10 THEN
RAISE e_too_many_sections;
ELSE
DBMS_OUTPUT.PUT_LINE ('Instructor, '||v_name||', teaches '||
v_tot_sections||' sections');
END IF;
EXCEPTION
WHEN e_too_many_sections THEN
DBMS_OUTPUT.PUT_LINE ('Instructor, '||v_name||
', teaches too much');
END;

.
/

-- ch9_3a.sql, version 1.0 (ROSENZWEIG y RAKHIMOV, 2009, 203).


DECLARE
v_my_name VARCHAR2(15) := 'ELENA SILVESTROVA';
BEGIN
DBMS_OUTPUT.PUT_LINE ('My name is '||v_my_name);
DECLARE
v_your_name VARCHAR2(15);
BEGIN
v_your_name := '&sv_your_name';
DBMS_OUTPUT.PUT_LINE ('Your name is '||v_your_name);
EXCEPTION
WHEN VALUE_ERROR THEN
DBMS_OUTPUT.PUT_LINE ('Error in the inner block');
DBMS_OUTPUT.PUT_LINE ('This name is too long');
END;
EXCEPTION
WHEN VALUE_ERROR THEN
DBMS_OUTPUT.PUT_LINE ('Error in the outer block');
DBMS_OUTPUT.PUT_LINE ('This name is too long');
END;
.
/

/*En el script anterior podemos observar que este no tiene exepciones, si quisieramos que muestre un error cuando el curso etnga mas de diez 
estuddiantes se muestre un mensaje de error. 
*/

DECLARE
v_students NUMBER(3) := 0;
BEGIN
SELECT COUNT(*)
INTO v_students
FROM enrollment e, section s
WHERE e.section_id = s.section_id
AND s.course_no = 25
AND s.section_id = 89;
IF v_students > 10 THEN
RAISE_APPLICATION_ERROR
(-20002, 'Course 25, section 89 has more than 10 students');
END IF;
DBMS_OUTPUT.PUT_LINE ('Course 25, section 89 has '||v_students||
' students');
END;

.
/

-- ch9_4b.sql, version 2.0 (ROSENZWEIG y RAKHIMOV, 2009, 207).

DECLARE
v_course_no NUMBER := 430;
v_total NUMBER;
e_no_sections EXCEPTION;
BEGIN
BEGIN
SELECT COUNT(*)
INTO v_total
FROM section
WHERE course_no = v_course_no;
IF v_total = 0 THEN
RAISE e_no_sections;
ELSE
DBMS_OUTPUT.PUT_LINE ('Course, '||v_course_no||
' has '||v_total||' sections');
END IF;
EXCEPTION
WHEN e_no_sections THEN
DBMS_OUTPUT.PUT_LINE ('There are no sections for course '||
v_course_no);
END;
DBMS_OUTPUT.PUT_LINE ('Done...');
END;
.
/

/*
Este script muestra el numero de seciones de una clase, pero debemos tener en cuenta que si queremos cambiar la exepcion e_no_sections vuelva
a ser un bloque exterior
*/

DECLARE
v_course_no NUMBER := 430;
v_total NUMBER;
e_no_sections EXCEPTION;
BEGIN
BEGIN
SELECT COUNT(*)
INTO v_total
FROM section
WHERE course_no = v_course_no;
IF v_total = 0 THEN
RAISE e_no_sections;
ELSE
DBMS_OUTPUT.PUT_LINE ('Course, '||v_course_no||
' has '||v_total||' sections');
END IF;
EXCEPTION
WHEN e_no_sections THEN
RAISE;
END;
DBMS_OUTPUT.PUT_LINE ('Done...');
EXCEPTION
WHEN e_no_sections THEN
DBMS_OUTPUT.PUT_LINE ('There are no sections for course '||
v_course_no);
END;
.
/


spool OFF;
