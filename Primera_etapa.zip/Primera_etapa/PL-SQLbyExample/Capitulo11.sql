spool C:\Users\mauri\Desktop\Segunda_evaluacion\Salidas\Capitulo11.txt
/*
rem **********************************************************
rem * Elaborado por:                                         *
rem * Taboada Sanchez Mauricio Manuel                        *                 
rem * Realizado el 30 de noviembre  de 2021                  *
rem * ROSENZWEIG,B &  RAKHIMOV,E (2009).                     *
rem *Oracle� PL/SQL�by Example,Boston,MA,USA:Perarson.       *
rem **********************************************************
*/

set colsep '|='
set describe linenum on
SET PAGESIZE 99;
SET LINESIZE 150
alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY';
alter session set NLS_DATE_LANGUAGE = 'ENGLISH';
SET SERVEROUTPUT ON;

/*
Explain what is declared in the following example. Describe what is happening to the record, and
explain how this results in the output:
(ROSENZWEIG &  RAKHIMOV, 2009, 239)
*/


DECLARE
	TYPE instructor_info IS RECORD
		(first_name instructor.first_name%TYPE,
		last_name instructor.last_name%TYPE,
		sections NUMBER);
	rv_instructor instructor_info;
BEGIN
	SELECT RTRIM(i.first_name), RTRIM(i.last_name), COUNT(*)
		INTO rv_instructor
		FROM instructor i, section s
		WHERE i.instructor_id = s.instructor_id
		AND i.instructor_id = 102
		GROUP BY i.first_name, i.last_name;
	DBMS_OUTPUT.PUT_LINE('Instructor, '||
		rv_instructor.first_name||
		' '||rv_instructor.last_name||
		', teaches '||rv_instructor.sections||
		' section(s)');
EXCEPTION
	WHEN NO_DATA_FOUND THEN
	DBMS_OUTPUT.PUT_LINE
	('There is no such instructor');
END;
.
/

/*
Define un tipo de registro que incluye los atributos firt_name, last_name y n�mero de 
cursos que imparte un instruvtor. 
En el cuerpo del bloque de c�digo, se selecciona dentro de ese registro la informaci�n
del instructor 102. 
Podr�amos definir un registro con m�s atributos, por ejemplo:
*/

DECLARE
	TYPE instructor_info IS RECORD
		(first_name instructor.first_name%TYPE,
		last_name instructor.last_name%TYPE,
		sections NUMBER, phone instructor.phone%TYPE);
	rv_instructor instructor_info;
BEGIN
	SELECT RTRIM(i.first_name), RTRIM(i.last_name), COUNT(*), RTRIM(i.phone) 
		INTO rv_instructor
		FROM instructor i, section s
		WHERE i.instructor_id = s.instructor_id
		AND i.instructor_id = 102
		GROUP BY i.first_name, i.last_name, i.phone;
	DBMS_OUTPUT.PUT_LINE('Instructor, '||
		rv_instructor.first_name||
		' '||rv_instructor.last_name||
		', teaches '||rv_instructor.sections||
		' section(s)'||', his phone number is: '||rv_instructor.phone);
EXCEPTION
	WHEN NO_DATA_FOUND THEN
	DBMS_OUTPUT.PUT_LINE
	('There is no such instructor');
END;
.
/

DECLARE
	CURSOR c_student_enroll IS
		SELECT s.student_id, first_name, last_name,
		COUNT(*) enroll,
			(CASE
			WHEN count(*) = 1 Then ' class.'
			WHEN count(*) is null then
			' no classes.'
			ELSE ' classes.'
			END) class
		FROM student s, enrollment e
		WHERE s.student_id = e.student_id
		AND s.student_id <110
		GROUP BY s.student_id, first_name, last_name;
	r_student_enroll c_student_enroll%ROWTYPE;
BEGIN
	OPEN c_student_enroll;
	LOOP
		FETCH c_student_enroll INTO r_student_enroll;
		EXIT WHEN c_student_enroll%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE('Student INFO: ID '||
		r_student_enroll.student_id||' is '||
		r_student_enroll.first_name|| ' ' ||
		r_student_enroll.last_name||
		' is enrolled in '||r_student_enroll.enroll||
		r_student_enroll.class);
	END LOOP;
	CLOSE c_student_enroll;
EXCEPTION
	WHEN OTHERS
	THEN
	IF c_student_enroll %ISOPEN
	THEN
	CLOSE c_student_enroll;
	END IF;
END;
.
/

/*
Este ejemplo muestra la infromaci�n de los estudiantes y el n�mero de cursos a los que 
est�n inscritos.
Nos apoyamos de un cursor. Otra forma de implementar el c�digo es usando un FOR para
cursores.
*/

DECLARE
	CURSOR c_student_enroll IS
		SELECT s.student_id, first_name, last_name,
		COUNT(*) enroll,
			(CASE
			WHEN count(*) = 1 Then ' class.'
			WHEN count(*) is null then
			' no classes.'
			ELSE ' classes.'
			END) class
		FROM student s, enrollment e
		WHERE s.student_id = e.student_id
		AND s.student_id <110
		GROUP BY s.student_id, first_name, last_name;
	r_student_enroll c_student_enroll%ROWTYPE;
BEGIN
	FOR r_student_enroll in c_student_enroll
	LOOP
		DBMS_OUTPUT.PUT_LINE('Student INFO: ID '||
		r_student_enroll.student_id||' is '||
		r_student_enroll.first_name|| ' ' ||
		r_student_enroll.last_name||
		' is enrolled in '||r_student_enroll.enroll||
		r_student_enroll.class);
	END LOOP;
EXCEPTION
	WHEN OTHERS
	THEN
		IF c_student_enroll %ISOPEN
			THEN
			CLOSE c_student_enroll;
		END IF;
END;
.
/


--(ROSENZWEIG &  RAKHIMOV, 2009, 248)

DECLARE
	v_sid student.student_id%TYPE;
	CURSOR c_student IS
		SELECT student_id, first_name, last_name
		FROM student
		WHERE student_id < 110;
	CURSOR c_course IS
		SELECT c.course_no, c.description
		FROM course c, section s, enrollment e
		WHERE c.course_no = s.course_no
		AND s.section_id = e.section_id
		AND e.student_id = v_sid;
BEGIN
	FOR r_student IN c_student
	LOOP
		v_sid := r_student.student_id;
		DBMS_OUTPUT.PUT_LINE(chr(10));
		DBMS_OUTPUT.PUT_LINE(' The Student '||
		r_student.student_id||' '||
		r_student.first_name||' '||
		r_student.last_name);
		DBMS_OUTPUT.PUT_LINE(' is enrolled in the '||
		'following courses: ');
		FOR r_course IN c_course
		LOOP
			DBMS_OUTPUT.PUT_LINE(r_course.course_no||
			'
			'||r_course.description);
		END LOOP;
	END LOOP;
END;
.
/

--(ROSENZWEIG &  RAKHIMOV, 2009, 234)

DECLARE
vr_zip ZIPCODE%ROWTYPE;
BEGIN
SELECT *
INTO vr_zip
FROM zipcode
WHERE rownum < 2;
DBMS_OUTPUT.PUT_LINE('City: '||vr_zip.city);
DBMS_OUTPUT.PUT_LINE('State: '||vr_zip.state);
DBMS_OUTPUT.PUT_LINE('Zip: '||vr_zip.zip);
END;
.
/

-- ch11_6a.sql (ROSENZWEIG &  RAKHIMOV, 2009, 234)

DECLARE
CURSOR c_student_enroll IS
SELECT s.student_id, first_name, last_name,
COUNT(*) enroll,
(CASE
WHEN count(*) = 1 Then ' class.'
WHEN count(*) is null then
' no classes.'
ELSE ' classes.'
END) class
FROM student s, enrollment e
WHERE s.student_id = e.student_id
AND s.student_id <110
GROUP BY s.student_id, first_name, last_name;
r_student_enroll c_student_enroll%ROWTYPE;
BEGIN
OPEN c_student_enroll;
LOOP
FETCH c_student_enroll INTO r_student_enroll;
EXIT WHEN c_student_enroll%NOTFOUND;
DBMS_OUTPUT.PUT_LINE('Student INFO: ID '||
r_student_enroll.student_id||' is '||
r_student_enroll.first_name|| ' ' ||
r_student_enroll.last_name||
' is enrolled in '||r_student_enroll.enroll||
r_student_enroll.class);
END LOOP;
CLOSE c_student_enroll;
EXCEPTION
WHEN OTHERS
THEN
IF c_student_enroll %ISOPEN
THEN
CLOSE c_student_enroll;
END IF;
END;
.
/

spool OFF;
