spool C:\Users\mauri\Desktop\Segunda_evaluacion\Salidas\Capitulo8PLSQL.txt
/*
rem **********************************************************
rem * Elaborado por:                                         *
rem * Taboada Sanchez Mauricio Manuel                        *                 
rem * Realizado el 30 de noviembre  de 2021                  *
rem * ROSENZWEIG,B &  RAKHIMOV,E (2009).                     *
rem *Oracle� PL/SQL�by Example,Boston,MA,USA:Perarson.       *
rem **********************************************************
*/

set colsep '|='
set describe linenum on
SET PAGESIZE 99;
SET LINESIZE 150
alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY';
alter session set NLS_DATE_LANGUAGE = 'ENGLISH';
SET SERVEROUTPUT ON;


-- In this exercise, you calculate the value of the square root of a number and display it on the screen. (ROSENZWEIG y RAKHIMOV, 2009, 167).

-- ch08_1a.sql, version 1.0

DECLARE
	v_num NUMBER := &sv_num;
BEGIN
	DBMS_OUTPUT.PUT_LINE ('Square root of '||v_num||' is '||SQRT(v_num));
EXCEPTION
	WHEN VALUE_ERROR THEN
	DBMS_OUTPUT.PUT_LINE ('An error has occurred');
END;
.
/
/

--Esta excepci�n se puede manejar inclusive sin el bloque manejador. 


DECLARE
	v_num NUMBER := &sv_num;
BEGIN
	IF v_num >= 0 THEN
		DBMS_OUTPUT.PUT_LINE ('Square root of '||v_num|| ' is '||SQRT(v_num));
	ELSE
		DBMS_OUTPUT.PUT_LINE ('A number cannot be negative');
	END IF;
END;
.
/


-- ch08_2a.sql, version 1.0
SET SERVEROUTPUT ON
DECLARE
	v_exists         NUMBER(1);
	v_total_students NUMBER(1);
	v_zip            CHAR(5):= '&sv_zip';
BEGIN
	SELECT count(*)
		INTO v_exists
		FROM zipcode
		WHERE zip = v_zip;
		
	IF v_exists != 0 THEN
		SELECT COUNT(*)
		INTO v_total_students
		FROM student
		WHERE zip = v_zip;
	DBMS_OUTPUT.PUT_LINE('There are '||v_total_students||' students');
	ELSE
		DBMS_OUTPUT.PUT_LINE (v_zip||' is not a valid zip');
	END IF;
EXCEPTION
	WHEN VALUE_ERROR OR INVALID_NUMBER THEN
		DBMS_OUTPUT.PUT_LINE ('An error has occurred');
END;
.
/
/
/
--Probar con valores 07024 00914 12345

--Insertar este estudiante
INSERT INTO student (student_id, salutation, first_name,
	last_name, zip, registration_date, created_by, created_date,
	modified_by, modified_date)
VALUES (STUDENT_ID_SEQ.NEXTVAL, 'Mr.', 'John', 'Smith', '07024',
SYSDATE, 'STUDENT', SYSDATE, 'STUDENT', SYSDATE);

COMMIT;


/

--�Por qu� hay error?

/*
Porque en las declaraciones la variable total students es de tipo NUMBER con longitud de 1. Al
agregar un estudiante m�s ya no puede ser almacenada en esa variable.
*/

SET SERVEROUTPUT ON
DECLARE
	v_exists         NUMBER(1);
	v_total_students NUMBER(1);
	v_zip            CHAR(5):= '&sv_zip';
BEGIN
	SELECT count(*)
		INTO v_exists
		FROM zipcode
		WHERE zip = v_zip;
		
	IF v_exists != 0 THEN
		SELECT COUNT(*)
		INTO v_total_students
		FROM student
		WHERE zip = v_zip;
	DBMS_OUTPUT.PUT_LINE('There are '||v_total_students||' students');
	ELSE
		DBMS_OUTPUT.PUT_LINE (v_zip||' is not a valid zip');
	END IF;
EXCEPTION
	WHEN VALUE_ERROR OR INVALID_NUMBER THEN
		DBMS_OUTPUT.PUT_LINE ('An error has occurred');
END;
.
/

SET SERVEROUTPUT ON
DECLARE
	v_exists         NUMBER(1);
	v_total_students NUMBER(2);
	v_zip            CHAR(5):= '&sv_zip';
BEGIN
	SELECT count(*)
		INTO v_exists
		FROM zipcode
		WHERE zip = v_zip;
		
	IF v_exists != 0 THEN
		SELECT COUNT(*)
		INTO v_total_students
		FROM student
		WHERE zip = v_zip;
	DBMS_OUTPUT.PUT_LINE('There are '||v_total_students||' students');
	ELSE
		DBMS_OUTPUT.PUT_LINE (v_zip||' is not a valid zip');
	END IF;
EXCEPTION
	WHEN VALUE_ERROR OR INVALID_NUMBER THEN
		DBMS_OUTPUT.PUT_LINE ('An error has occurred');
END;
.
/


-----------------------------------------------------
-- �C�mo cambiar�a el gui�n para mostrar el nombre y apellido de un estudiante en lugar de mostrar el total
--  del n�mero de estudiantes para cualquier valor dado de un zip?


DECLARE
	v_exists       NUMBER(1);
	v_student_name VARCHAR2(30);
	v_zip          CHAR(5):= '&sv_zip';
BEGIN
	SELECT count(*)
		INTO v_exists
		FROM zipcode
		WHERE zip = v_zip;
	IF v_exists != 0 THEN
		SELECT first_name||' '||last_name
			INTO v_student_name
			FROM student
			WHERE zip = v_zip
			AND rownum = 1;
	DBMS_OUTPUT.PUT_LINE ('Student name is '||v_student_name);
	ELSE
		DBMS_OUTPUT.PUT_LINE (v_zip||' is not a valid zip');
	END IF;
EXCEPTION
	WHEN VALUE_ERROR OR INVALID_NUMBER THEN
		DBMS_OUTPUT.PUT_LINE ('An error has occurred');
	WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('There are no students for this value of zip code');
END;
.
/


--(ROSENZWEIG y RAKHIMOV, 2009, 178).

DECLARE 
	v_student_id NUMBER := &sv_student_id;
	v_name_student      VARCHAR(15);
BEGIN
	select first_name
		into v_name_student
		from student
		where student_id=v_student_id;
	DBMS_OUTPUT.PUT_LINE ('Ya existe, se llama:' || v_name_student);
EXCEPTION
	WHEN NO_DATA_FOUND THEN
		INSERT INTO student (student_id, salutation, first_name,
	last_name, zip, registration_date, created_by, created_date, modified_by, modified_date)
		VALUES (v_student_id, 'Ms.', 'Daniela', 'Smith', '07024', SYSDATE, 'STUDENT', SYSDATE, 'STUDENT', SYSDATE);

END;

.
/


select student_id, first_name from student
where student_id in (500,501);

-- ch08_2a.sql, version 1.0
SET SERVEROUTPUT ON
DECLARE
    v_exists NUMBER(1);
    v_total_students NUMBER(1);
    v_zip CHAR(5):= '&sv_zip';
BEGIN
    SELECT count(*)
        INTO v_exists
        FROM zipcode
    WHERE zip = v_zip;
    IF v_exists != 0 THEN
        SELECT COUNT(*)
            INTO v_total_students
            FROM student
        WHERE zip = v_zip;
        DBMS_OUTPUT.PUT_LINE
         ('There are '||v_total_students||' students');
ELSE
    DBMS_OUTPUT.PUT_LINE (v_zip||' is not a valid zip');
END IF;
EXCEPTION
    WHEN VALUE_ERROR OR INVALID_NUMBER THEN
    DBMS_OUTPUT.PUT_LINE ('An error has occurred');
END;

.
/

--Este script usa un manejador de exepciones ya que manejamos  dos diferentes, muestra el numero total de estudioantes, pero 
--si quisieramos mostar su nombre y apellido debemos hacer lo siguente: 

SET SERVEROUTPUT ON
DECLARE
v_exists NUMBER(1);
v_student_name VARCHAR2(30);
v_zip CHAR(5):= '&sv_zip';
BEGIN
SELECT count(*)
INTO v_exists
FROM zipcode
WHERE zip = v_zip;
IF v_exists != 0 THEN
SELECT first_name||' '||last_name
INTO v_student_name
FROM student
WHERE zip = v_zip
AND rownum = 1;
DBMS_OUTPUT.PUT_LINE ('Student name is '||v_student_name);
ELSE
DBMS_OUTPUT.PUT_LINE (v_zip||' is not a valid zip');
END IF;
EXCEPTION
WHEN VALUE_ERROR OR INVALID_NUMBER THEN
DBMS_OUTPUT.PUT_LINE ('An error has occurred');
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE
('There are no students for this value of zip code');
END;

.
/

--(ROSENZWEIG y RAKHIMOV, 2009, 174).

DECLARE
v_instructor_id NUMBER := &sv_instructor_id;
v_instructor_name VARCHAR2(50);
BEGIN
SELECT first_name||' '||last_name
INTO v_instructor_name
FROM instructor
WHERE instructor_id = v_instructor_id;
DBMS_OUTPUT.PUT_LINE ('Instructor name is '||v_instructor_name);
EXCEPTION
WHEN OTHERS THEN
DBMS_OUTPUT.PUT_LINE ('An error has occurred');
END;
.
/

--Como podemos ver en este ejemplo el mal uso de las exepciones ya que como podemos ver auque el valor sea incorrecto el programa se ejecuta satisfactoriamente
--lo cual es una mala practica de progrmacion  


/
spool OFF;
