spool C:\schemasetup\Capitulo7SQLBS.txt

PROMPT **********************************************************
PROMPT * Elaborado por:                                         *
PROMPT * Taboada Sanchez Mauricio Manuel                        *                 
PROMPT * Realizado el 30 de noviembre  de 2021                  *
PROMPT * Rischert,A (2004)."Chapter 7. Subqueries".             *
PROMPT *Ramagnano,L, Oracle� SQL�by Example(446-477). 	      *
PROMPT *Pearson.  					                            *
PROMPT **********************************************************


PROMPT Establecer formato para las tablas

set colsep '|=|'
set describe linenum on
SET PAGESIZE 99;
SET LINESIZE 150
alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY';
alter session set NLS_DATE_LANGUAGE = 'ENGLISH';
PROMPT para estos ejercicios necesitamos este tipo de formato


PROMPT ----------------------------- EJERCICIO B. LAB 7.1.3--------------------------------------------------------------------------------

PROMPT Select the sections and their capacity where the capacity equals the number of students enrolled.(Rischert, 2004, 375). 

SELECT section_id, capacity
FROM section
WHERE (section_id, capacity) IN
	(SELECT section_id, COUNT(*)
	FROM enrollment
	GROUP BY section_id);

PROMPT mostrar todas las dem�s secciones

SELECT section_id, capacity
FROM section
WHERE (section_id, capacity) NOT IN
	(SELECT section_id, COUNT(*)
	FROM enrollment
	GROUP BY section_id)
and ROWNUM<=15;



PROMPT ----------------------------- EJERCICIO B. LAB 7.2.2--------------------------------------------------------------------------------

PROMPT Show the STUDENT_ID, last name, and first name of students enrolled in three or more classes. (Rischert, 2004, 391).
	
SELECT first_name, last_name, student_id
FROM student s
WHERE EXISTS
	(SELECT NULL
	FROM enrollment
	WHERE s.student_id = student_id
	GROUP BY student_id
	HAVING COUNT(*) >= 3);

PROMPT otra manera de hacerlo.

SELECT first_name, last_name, s.student_id
FROM enrollment e, student s
WHERE e.student_id = s.student_id
GROUP BY first_name, last_name, s.student_id
HAVING COUNT(*) >= 3;

PROMPT usando IN

SELECT first_name, last_name, student_id
FROM student
WHERE student_id IN
	(SELECT student_id
	FROM enrollment
	GROUP BY student_id
	HAVING COUNT(*) >= 3);

PROMPT Una manera no tipica de hacerlo

SELECT last_name, first_name, student_id
FROM student s
WHERE 3 <= (SELECT COUNT(*)
FROM enrollment
WHERE s.student_id = student_id);

PROMPT ----------------------------- EJERCICIO B. LAB 7.3.1--------------------------------------------------------------------------------

PROMPT Write the exercise question that is answered by the following query. (Rischert, 2004, 408).

SELECT g.student_id, section_id, g.numeric_grade,
gr.average
FROM grade g JOIN
	(SELECT section_id, AVG(numeric_grade) average
	FROM grade
	WHERE section_id IN (94, 106)
	AND grade_type_code = 'FI'
	GROUP BY section_id ) gr
USING (section_id)
WHERE g.grade_type_code = 'FI'
AND g.numeric_grade > gr.average;

PROMPT Escribit el ID de los estudiantes que tuvieron una calificaci�n final mayor al promedio de la secciones 94 y 106. 

PROMPT ----------------------------- EJERCICIO A. LAB 7.1.3--------------------------------------------------------------------------------

PROMPT  Determine the STUDENT_ID and last name of students with the highest FINAL_GRADE

PROMPT for each section. Also include the SECTION_ID and the FINAL_GRADE columns in the

PROMPT result.

PROMPT (Rischert, 2004, 375). 

SELECT s.student_id, s.last_name, e.final_grade,
e.section_id
FROM enrollment e, student s
WHERE e.student_id = s.student_id
AND (e.final_grade, e.section_id) IN
(SELECT MAX(final_grade), section_id
FROM enrollment
GROUP BY section_id);

PROMPT ----------------------------- EJERCICIO A. LAB 7.2.2--------------------------------------------------------------------------------

PROMPT Write a SQL statement to determine the total number of students enrolled using the

PROMPT EXISTS operator. Count students enrolled in more than one course as one.

PROMPT (Rischert, 2004, 391).
	
SELECT COUNT(*)
FROM student s
WHERE EXISTS
(SELECT NULL
FROM enrollment
WHERE student_id = s.student_id);


PROMPT ----------------------------- EJERCICIO A. LAB 7.3.1--------------------------------------------------------------------------------

PROMPT Write the query that displays the SECTION_ID and COURSE_NO columns along with the

PROMPT number of students enrolled for sections with the IDs of 93, 101, and 103. Utilize a

PROMPT scalar subquery to write the query. The result should look similar to the following

PROMPT output.

PROMPT (Rischert, 2004, 408).

SELECT section_id, course_no,
(SELECT COUNT(*)
FROM enrollment e
WHERE s.section_id = e.section_id)
AS num_enrolled
FROM section s
WHERE section_id IN (101, 103, 93);

spool OFF;
