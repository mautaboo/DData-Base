spool C:\schemasetup\Capitulo13PLSQL.txt


PROMPT **********************************************************
PROMPT * Elaborado por:                                         *
PROMPT * Taboada Sanchez Mauricio Manuel                        *                 
PROMPT * Realizado el 30 de noviembre  de 2021                  *
PROMPT * ROSENZWEIG,B    RAKHIMOV,E (2009).                     *
PROMPT *Oracle� PL/SQL�by Example,Boston,MA,USA:Perarson.     *
PROMPT **********************************************************


SET colsep '|=' 
SET describe linenum on 
SET PAGESIZE 99; 
SET LINESIZE 150 
alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY'; 
alter session set NLS_DATE_LANGUAGE = 'ENGLISH'; 
SET SERVEROUTPUT ON; 



PROMPT Si a una instrucci�n INSERT emitida contra la tabla INSTRUCTOR le falta un valor para la columna ZIP,
PROMPT El disparador genera una excepci�n?
PROMPT Cuando no hy valor para el zipcode
PROMPT (ROSENZWEIG    RAKHIMOV, 2009, 275)


SET SERVEROUTPUT ON;
CREATE OR REPLACE TRIGGER instructor_bi
	BEFORE INSERT ON INSTRUCTOR
	FOR EACH ROW
DECLARE
	v_work_zip CHAR(1);
BEGIN
    DBMS_OUTPUT.PUT_LINE(HOLA ESCOM);
	:NEW.CREATED_BY := USER;
	:NEW.CREATED_DATE := SYSDATE;
	:NEW.MODIFIED_BY := USER;
	:NEW.MODIFIED_DATE := SYSDATE;
	SELECT 'Y'
	INTO v_work_zip
	FROM zipcode
	WHERE zip = :NEW.ZIP;
EXCEPTION
	WHEN NO_DATA_FOUND THEN
		RAISE_APPLICATION_ERROR (-20001, 'Zip code is not valid!');
END;
/


CREATE OR REPLACE TRIGGER instructor_bi
	BEFORE INSERT ON INSTRUCTOR
	FOR EACH ROW
DECLARE
	v_work_zip CHAR(1);
BEGIN
    DBMS_OUTPUT.PUT_LINE(HOLA ESCOM);
	:NEW.INSTRUCTOR_ID:= INSTRUCTOR_ID_SEQ.NEXTVAL;
	:NEW.CREATED_BY := USER;
	:NEW.CREATED_DATE := SYSDATE;
	:NEW.MODIFIED_BY := USER;
	:NEW.MODIFIED_DATE := SYSDATE;
	SELECT 'Y'
	INTO v_work_zip
	FROM zipcode
	WHERE zip = :NEW.ZIP;
EXCEPTION
	WHEN NO_DATA_FOUND THEN
		RAISE_APPLICATION_ERROR (-20001, 'Zip code is not valid!');
END;
/

SELECT INSTRUCTOR_ID_SEQ.NEXTVAL FROM DUAL;


col FECHA FORMAT A25
col instructor_id FORMAT 9999
col first_name FORMAT A12
col last_name FORMAT A12
set colsep '|=|'
select instructor_id , first_name , last_name, 
 created_by, to_char(created_date,'dd-MONTH-YYYY HH24:MI:SS') FECHA
 from instructor;

select * from instructor 
	where instructor_id=114;
	

select * from instructor 
	where instructor_id=119;

insert into Instructor (instructor_id, salutation, first_name, last_name, street_address,
	zip, phone) VALUES (114,'mr', 'Mauricio', 'Taboada','Mexico','10019','581192059');
	
insert into Instructor (instructor_id, salutation, first_name, last_name, street_address,
	zip, phone) VALUES (115,'mr', 'Jose', 'Taboada','Mexico','10019','581192059');

insert into Instructor (salutation, first_name, last_name, street_address,
	zip, phone) VALUES ('mr', 'Rodrigo', 'Taboada','Mexico','10019','581192059');

insert into Instructor (salutation, first_name, last_name, street_address,
	zip, phone) VALUES ('mr', 'Pedro', 'Taboada','Mexico','10019','581192059');

insert into Instructor (salutation, first_name, last_name, street_address,
	zip, phone) VALUES ('mr', 'Juan', 'Taboada','Mexico','10019','581192059');


insert into Instructor (salutation, first_name, last_name, street_address,
	zip, phone) VALUES ('mr', 'Uriel', 'Rodriguez','Mexico','2501','55984524');

delete from Instructor where instructor_id=114;

PROMPT ------ ch13_1b.sql, version 2.0 -----------
CREATE OR REPLACE TRIGGER instructor_bi
	BEFORE INSERT ON INSTRUCTOR
	FOR EACH ROW
DECLARE
	v_work_zip CHAR(1);
BEGIN
	:NEW.CREATED_BY := USER;
	:NEW.CREATED_DATE := SYSDATE;
	:NEW.MODIFIED_BY := USER;
	:NEW.MODIFIED_DATE := SYSDATE;
	IF :NEW.ZIP IS NULL THEN
		RAISE_APPLICATION_ERROR (-20002, 'Zip code is missing!');
	ELSE
		SELECT 'Y'
		INTO v_work_zip
		FROM zipcode
		WHERE zip = :NEW.ZIP;
	END IF;
EXCEPTION
	WHEN NO_DATA_FOUND THEN
		RAISE_APPLICATION_ERROR (-20001, 'Zip code is not valid!');
END;
/

PROMPT ------- (ROSENZWEIG    RAKHIMOV, 2009, 283) ----------


INSERT INTO COURSE (description, cost, prerequisite)
VALUES ('Test Course', 0, 999);


CREATE OR REPLACE TRIGGER course_bi
	BEFORE INSERT ON COURSE
	FOR EACH ROW
BEGIN
	:NEW.COURSE_NO:= COURSE_NO_SEQ.NEXTVAL;
	:NEW.CREATED_BY:= USER;
	:NEW.CREATED_DATE := SYSDATE;
	:NEW.MODIFIED_BY:= USER;
	:NEW.MODIFIED_DATE := SYSDATE;
END;
/

INSERT INTO COURSE (description, cost, prerequisite)
VALUES ('Test Course', 0, 999);

PROMPT -------- Modificado --------


CREATE OR REPLACE TRIGGER course_bi
	BEFORE INSERT ON COURSE
	FOR EACH ROW
DECLARE
	v_prerequisite COURSE.COURSE_NO%TYPE;
BEGIN
	IF :NEW.PREREQUISITE IS NOT NULL THEN
		SELECT course_no
		INTO v_prerequisite
		FROM course
		WHERE course_no = :NEW.PREREQUISITE;
	END IF;
	:NEW.COURSE_NO:= COURSE_NO_SEQ.NEXTVAL;
	:NEW.CREATED_BY:= USER;
	:NEW.CREATED_DATE := SYSDATE;
	:NEW.MODIFIED_BY:= USER;
	:NEW.MODIFIED_DATE := SYSDATE;
EXCEPTION
	WHEN NO_DATA_FOUND THEN
		RAISE_APPLICATION_ERROR (-20001, 'NO PRE');
END;
/

SELECT course_no from course;

INSERT INTO COURSE (description, cost, prerequisite)
VALUES ('Test Course', 20000, 450);

INSERT INTO COURSE (description, cost)
VALUES ('Testing Course', 20000);


PROMPT  Crear una vista y un disparador
PROMPT  -------- (ROSENZWEIG ,RAKHIMOV, 2009, 288) --------

CREATE VIEW student_address AS 
SELECT s.student_id, s.first_name, s.last_name,
	s.street_address, z.city, z.state, z.zip
	FROM student s
	JOIN zipcode z
	ON (s.zip = z.zip);



PROMPT ----- ch13_3a.sql, version 1.0 -----

CREATE OR REPLACE TRIGGER student_address_ins
	INSTEAD OF INSERT ON 
	student_address;
	FOR EACH ROW
BEGIN
	INSERT INTO STUDENT
	(student_id, first_name, last_name, street_address, zip,
	registration_date, created_by, created_date, modified_by,
	modified_date)
	VALUES
	(:NEW.student_id, :NEW.first_name, :NEW.last_name,
	:NEW.street_address, :NEW.zip, SYSDATE, USER, SYSDATE, USER,
	SYSDATE);
END;
/

INSERT INTO student_address VALUES (STUDENT_ID_SEQ.NEXTVAL, 'John', 'Smith', '123 Main Street','New York', 'NY', '10019');

INSERT INTO student_address VALUES (STUDENT_ID_SEQ.NEXTVAL, 'Jason', 'Smith', '123 Main Street','New York', 'NY', '12345');



PROMPT Modifique el disparador para que verifique el valor del c�digo postal proporcionado por la instrucci�n"INSERT"
PROMPT contra la tabla ZIPCODE. Si la tabla ZIPCODE no tiene un registro correspondiente, el disparador debe
PROMPT cree un nuevo registro para el valor dado de zip antes de agregar un nuevo registro a la tabla ESTUDIANTE.
PROMPT -------- (ROSENZWEIG ,RAKHIMOV, 2009, 289) --------------


CREATE OR REPLACE TRIGGER student_address_ins
	INSTEAD OF INSERT ON 
	student_address
	FOR EACH ROW
DECLARE
	v_zip VARCHAR2(5);
BEGIN
	BEGIN
		SELECT zip
			INTO v_zip
			FROM zipcode
			WHERE zip = :NEW.zip;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			INSERT INTO ZIPCODE
			(zip, city, state, created_by, created_date, modified_by, modified_date)
			VALUES
			(:NEW.zip, :NEW.city, :NEW.state, USER, SYSDATE, USER, SYSDATE);
	END;
	INSERT INTO STUDENT
	(student_id, first_name, last_name, street_address, zip,
	registration_date, created_by, created_date, modified_by,
	modified_date)
	VALUES
	(:NEW.student_id, :NEW.first_name, :NEW.last_name,
	:NEW.street_address, :NEW.zip, SYSDATE, USER, SYSDATE, USER,
	SYSDATE);
END;
/


INSERT INTO student_address VALUES (STUDENT_ID_SEQ.NEXTVAL, 'John', 'Smith', '123 Main Street','New York', 'NY', '12345');



spool OFF;
