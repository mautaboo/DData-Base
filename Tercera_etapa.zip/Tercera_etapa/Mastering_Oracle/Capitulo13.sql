spool C:\schemasetup\Capitulo13MSO.txt

rem *****************************************************
rem * Elaborado por:                                    *
rem * Taboada Sanchez Mauricio Manuel                   *
rem *Mishra S., Beaulieu A. (2002). 		         	*
rem *Chapter 13 Advanced Analytic SQL en Mastering 	    *
rem *Oracle						                        *
rem * SQL (pp. 157-174).Gravenstein Highway North,	    *
rem * Sebastopol, CA 95472. 				            *
rem *****************************************************

rem Establecer formato para las tablas

set colsep '|=|'
set describe linenum on
SET PAGESIZE 99;
SET LINESIZE 150

alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY';
alter session set NLS_DATE_LANGUAGE= 'ENGLISH';
rem para estos ejercicios necesitamos este tipo de formato

rem Ejemplo (Mishra y Beaulieu, 2002, 270):


SELECT c.name cust_name,
big_custs.cust_sales cust_sales, r.name region_name,
100 * ROUND(big_custs.cust_sales /
big_custs.region_sales, 2) percent_of_region
FROM region r, customer c,
	(SELECT cust_sales.cust_nbr cust_nbr, cust_sales.region_id region_id,
	cust_sales.tot_sales cust_sales,
	region_sales.tot_sales region_sales
	FROM
		(SELECT o.region_id region_id, SUM(o.tot_sales) tot_sales
		FROM orders o
		WHERE o.year = 2001
		GROUP BY o.region_id) region_sales,
		(SELECT o.cust_nbr cust_nbr, o.region_id region_id,
		SUM(o.tot_sales) tot_sales
		FROM orders o
		WHERE o.year = 2001
		GROUP BY o.cust_nbr, o.region_id) cust_sales
	WHERE cust_sales.region_id = region_sales.region_id
	AND cust_sales.tot_sales > (region_sales.tot_sales * .2)) big_custs
WHERE big_custs.cust_nbr = c.cust_nbr
AND big_custs.region_id = r.region_id;

SELECT c.name cust_name,
cust_sales.tot_sales cust_sales, r.name region_name,
100 * ROUND(cust_sales.tot_sales /
cust_sales.region_sales, 2) percent_of_region
FROM region r, customer c,
	(SELECT o.region_id region_id, o.cust_nbr cust_nbr,
	SUM(o.tot_sales) tot_sales,
	SUM(SUM(o.tot_sales)) OVER (PARTITION BY o.region_id) region_sales
	FROM orders o
	WHERE o.year = 2001
	GROUP BY o.region_id, o.cust_nbr) cust_sales
WHERE cust_sales.tot_sales > (cust_sales.region_sales * .2)
AND cust_sales.region_id = r.region_id
AND cust_sales.cust_nbr = c.cust_nbr;



rem Ejercicios  RANK, DENSE_RANK, and ROW_NUMBER

SELECT region_id, cust_nbr,
SUM(tot_sales) cust_sales,
RANK( ) OVER (ORDER BY SUM(tot_sales) DESC) sales_rank,
DENSE_RANK( ) OVER (ORDER BY SUM(tot_sales) DESC) sales_dense_rank,
ROW_NUMBER( ) OVER (ORDER BY SUM(tot_sales) DESC) sales_number
FROM orders
WHERE year = 2001
GROUP BY region_id, cust_nbr
ORDER BY 6;


rem Ejemplo (Mishra y Beaulieu, 2002, 278)

SELECT
MIN(region_id)
	KEEP (DENSE_RANK FIRST ORDER BY SUM(tot_sales) DESC) best_region,
MIN(region_id)
	KEEP (DENSE_RANK LAST ORDER BY SUM(tot_sales) DESC) worst_region
FROM orders
WHERE year = 2001
GROUP BY region_id;

SELECT
MAX(region_id)
	KEEP (DENSE_RANK FIRST ORDER BY SUM(tot_sales) DESC) best_region,
MAX(region_id)
	KEEP (DENSE_RANK LAST ORDER BY SUM(tot_sales) DESC) worst_region
FROM orders
WHERE year = 2001
GROUP BY region_id;



rem Ejemplo (Mishra y Beaulieu, 2002, 281)

SELECT region_id, cust_nbr,
SUM(tot_sales) cust_sales,
WIDTH_BUCKET(SUM(tot_sales), 1, 3000000, 3) sales_buckets
FROM orders
WHERE year = 2001
GROUP BY region_id, cust_nbr
ORDER BY 3;

SELECT region_id, cust_nbr,
SUM(tot_sales) cust_sales,
CUME_DIST( ) OVER (ORDER BY SUM(tot_sales) DESC) sales_cume_dist,
PERCENT_RANK( ) OVER (ORDER BY SUM(tot_sales) DESC) sales_percent_rank
FROM orders
WHERE year = 2001
GROUP BY region_id, cust_nbr
ORDER BY 3 DESC;

/*
Usando nada m�s ex�tico que las vistas en l�nea, podemos construir una sola consulta que genere los resultados deseados. La soluci�n, sin embargo, tiene las siguientes deficiencias:
� La consulta es bastante compleja.
� Se requieren dos pasadas por las mismas filas de la tabla de pedidos para generar los diferentes niveles de agregaci�n que necesita la consulta. 

(Mishra y Beaulieu, 2002, 269)
*/

SELECT c.name cust_name,
big_custs.cust_sales cust_sales, r.name region_name,
100 * ROUND(big_custs.cust_sales /
big_custs.region_sales, 2) percent_of_region
FROM region r, customer c,
(SELECT cust_sales.cust_nbr cust_nbr, cust_sales.region_id region_id,
cust_sales.tot_sales cust_sales,
region_sales.tot_sales region_sales
FROM
(SELECT o.region_id region_id, SUM(o.tot_sales) tot_sales
FROM orders o
WHERE o.year = 2001
GROUP BY o.region_id) region_sales,
(SELECT o.cust_nbr cust_nbr, o.region_id region_id,
SUM(o.tot_sales) tot_sales
FROM orders o
WHERE o.year = 2001
GROUP BY o.cust_nbr, o.region_id) cust_sales
WHERE cust_sales.region_id = region_sales.region_id
AND cust_sales.tot_sales > (region_sales.tot_sales * .2)) big_custs
WHERE big_custs.cust_nbr = c.cust_nbr
AND big_custs.region_id = r.region_id;




spool OFF;
