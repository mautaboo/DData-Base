spool C:\schemasetup\Capitulo4MSO.txt

rem *****************************************************
rem * Elaborado por:                                    *
rem * Taboada Sanchez Mauricio Manuel                   *
rem *Mishra S., Beaulieu A. (2002). 		         	*
rem *Chapter 4 Group Operations			                *
rem * SQL (pp. 157-174).Gravenstein Highway North,	    *
rem * Sebastopol, CA 95472. 				            *
rem *****************************************************

rem Establecer formato para las tablas

set colsep '|=|'
set describe linenum on
SET PAGESIZE 99;
SET LINESIZE 150

alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY';
alter session set NLS_DATE_LANGUAGE= 'ENGLISH';
rem para estos ejercicios necesitamos este tipo de formato


rem USAR GROUP BY con una INLINE VIEW

SELECT ROWNUM, V.*
FROM (SELECT CUST_NBR, COUNT(ORDER_NBR)
FROM CUST_ORDER GROUP BY CUST_NBR) V;

rem GROUP BY Y NULL

SELECT CUST_NBR, ORDER_DT, COUNT(ORDER_NBR)
FROM CUST_ORDER
GROUP BY CUST_NBR, ORDER_DT;

rem HAVING CLAUSE

SELECT CUST_NBR, COUNT(ORDER_NBR)
FROM CUST_ORDER
GROUP BY CUST_NBR
HAVING CUST_NBR < 260;

rem******************************************************
rem *Chapter 4 Group Operations			                *
rem * SQL (pp. 157-174).Gravenstein Highway North,	    *
rem * Sebastopol, CA 95472. 				            *
rem *****************************************************

rem similar a where, funciona como filtro

SELECT CUST_NBR, COUNT(ORDER_NBR)
FROM CUST_ORDER
GROUP BY CUST_NBR
HAVING COUNT(ORDER_NBR) > 2;


SELECT CUST_NBR, COUNT(ORDER_NBR)
FROM CUST_ORDER
GROUP BY CUST_NBR
HAVING ORDER_DT < SYSDATE;
rem error porque ORDER_DT no est� en lista de select

rem tener HAVING Y WHERE JUNTAS
SELECT CUST_NBR, COUNT(ORDER_NBR)
FROM CUST_ORDER
WHERE SALE_PRICE > 25
GROUP BY CUST_NBR
HAVING COUNT(ORDER_NBR) > 1;

rem******************************************************
rem *Chapter 4 Group Operations			                *
rem * SQL (pp. 157-174).Gravenstein Highway North,	    *
rem * Sebastopol, CA 95472. 				            *
rem *****************************************************


SELECT CUST_NBR, COUNT(ORDER_NBR)
FROM CUST_ORDER
GROUP BY CUST_NBR
HAVING COUNT(ORDER_NBR) > 1;


SELECT CUST_NBR, COUNT(ORDER_NBR)
FROM CUST_ORDER
HAVING COUNT(ORDER_NBR) > 1
GROUP BY CUST_NBR;

rem******************************************************
rem *Chapter 4 Group Operations			                *
rem * SQL (pp. 157-174).Gravenstein Highway North,	    *
rem * Sebastopol, CA 95472. 				            *
rem *****************************************************


SELECT CUST_NBR, COUNT(ORDER_NBR)
FROM CUST_ORDER
WHERE SALE_PRICE > 25
GROUP BY CUST_NBR;



spool OFF;
