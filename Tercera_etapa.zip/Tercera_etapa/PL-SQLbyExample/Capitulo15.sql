spool C:\schemasetup\Capitulo15PLSQL.txt

/*
rem *******************************************************
rem * Elaborado por:                                      *
rem * Taboada Sanchez Mauricio Manuel                     *       
rem * ROSENZWEIG,B &  RAKHIMOV,E (2009).                  *
rem *Oracle� PL/SQL�by Example,Boston,MA,USA:Perarson.    *
rem *******************************************************
*/

set colsep '|='
set describe linenum on
SET PAGESIZE 99;
SET LINESIZE 150
alter session set NLS_DATE_FORMAT = 'DD-MON-YYYY';
alter session set NLS_DATE_LANGUAGE = 'ENGLISH';
SET SERVEROUTPUT ON;


-- Ejemplos (ROSENZWEIG y RAKHIMOV, 2009, 317).
-- Asociatie arrays

DECLARE
	CURSOR name_cur IS	
		SELECT last_name
		FROM student
		WHERE rownum <= 10;
	TYPE last_name_type IS TABLE OF student.last_name%TYPE
	INDEX BY BINARY_INTEGER;
	last_name_tab last_name_type;
	v_counter INTEGER := 0;
BEGIN
	FOR name_rec IN name_cur LOOP
		v_counter := v_counter + 1;
		last_name_tab(v_counter) := name_rec.last_name;
		DBMS_OUTPUT.PUT_LINE ('last_name('||v_counter||'): '||
		last_name_tab(v_counter));
	END LOOP;
END;
.
/

-- Nested table

DECLARE
	CURSOR name_cur IS
		SELECT last_name
		FROM student
		WHERE rownum <= 10;
	TYPE last_name_type IS TABLE OF student.last_name%TYPE;
	last_name_tab last_name_type := last_name_type();
	v_counter INTEGER := 0;
BEGIN
	FOR name_rec IN name_cur LOOP
		v_counter := v_counter + 1;
		last_name_tab.EXTEND;
		last_name_tab(v_counter) := name_rec.last_name;
		DBMS_OUTPUT.PUT_LINE ('last_name('||v_counter||'): '||
		last_name_tab(v_counter));
	END LOOP;
END;

.
/


-- ch15_1c.sql, version 3.0 (ROSENZWEIG y RAKHIMOV, 2009, 327). MOdificado

DECLARE
	CURSOR course_cur IS
		SELECT description
		FROM course;
	TYPE course_type IS TABLE OF course.description%TYPE
	INDEX BY BINARY_INTEGER;
	course_tab course_type;
	v_counter INTEGER := 0;
BEGIN
	FOR course_rec IN course_cur LOOP
		v_counter := v_counter + 1;
		course_tab(v_counter):= course_rec.description;
	END LOOP;
	FOR i IN 1..v_counter LOOP
		DBMS_OUTPUT.PUT_LINE('course('||i||'): '||course_tab(i));
	END LOOP;
	DBMS_OUTPUT.PUT_LINE('course('||course_tab.FIRST||'): '|| course_tab(course_tab.FIRST));
	DBMS_OUTPUT.PUT_LINE('course('||course_tab.LAST||'): '|| course_tab(course_tab.LAST));
	
	DBMS_OUTPUT.PUT_LINE ('Total number of elements: '|| course_tab.COUNT);

END;
.
/

--�Que pasa si consultamos el �ndice 0?

DECLARE
	TYPE course_type IS TABLE OF INTEGER
	INDEX BY BINARY_INTEGER;
	course_tab course_type;
	v_counter INTEGER := 0;
BEGIN
	course_tab(0):= 4;
	course_tab(-1):= 5;
	DBMS_OUTPUT.PUT_LINE('course(0): '|| course_tab(0));
	DBMS_OUTPUT.PUT_LINE('course(-1): '|| course_tab(-1));
	DBMS_OUTPUT.PUT_LINE('course('||course_tab.FIRST||'): '|| course_tab(course_tab.FIRST));
	DBMS_OUTPUT.PUT_LINE('course('||course_tab.LAST||'): '|| course_tab(course_tab.LAST));
	DBMS_OUTPUT.PUT_LINE ('Total number of elements: '|| course_tab.COUNT);
END;
.
/
-- SI SE PUEDE INICIAR EN 0 incluso en negativos

-- Ejemplo. (ROSENZWEIG y RAKHIMOV, 2009, 325).

DECLARE
	TYPE index_by_type IS TABLE OF NUMBER
		INDEX BY BINARY_INTEGER;
	index_by_table index_by_type;
	TYPE nested_type IS TABLE OF NUMBER;
	nested_table nested_type := nested_type(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
BEGIN

	FOR i IN 1..10 LOOP
		index_by_table(i) := i;
	END LOOP;
	IF index_by_table.EXISTS(3) THEN
		DBMS_OUTPUT.PUT_LINE ('index_by_table(3) = '||index_by_table(3));
	END IF;
	-- delete 10th element from a collection
	nested_table.DELETE(10);
	-- delete elements 1 through 3 from a collection
	nested_table.DELETE(1,3);
	index_by_table.DELETE(10);
	DBMS_OUTPUT.PUT_LINE ('nested_table.COUNT = '||nested_table.COUNT);
	DBMS_OUTPUT.PUT_LINE ('index_by_table.COUNT = '|| index_by_table.COUNT);
	DBMS_OUTPUT.PUT_LINE ('nested_table.FIRST = '||nested_table.FIRST);
	DBMS_OUTPUT.PUT_LINE ('nested_table.LAST = '||nested_table.LAST);
	DBMS_OUTPUT.PUT_LINE ('index_by_table.FIRST = '|| index_by_table.FIRST);
	DBMS_OUTPUT.PUT_LINE ('index_by_table.LAST ='||index_by_table.LAST);
	DBMS_OUTPUT.PUT_LINE ('nested_table.PRIOR(2) = '||nested_table. PRIOR(2));
	DBMS_OUTPUT.PUT_LINE ('nested_table.NEXT(2) = '||nested_table.NEXT(2));
	DBMS_OUTPUT.PUT_LINE ('index_by_table.PRIOR(2) = '||index_by_table.PRIOR(2));
	DBMS_OUTPUT.PUT_LINE ('index_by_table.NEXT(2) = '||index_by_table.NEXT(2));
	-- Trim last two elements
	nested_table.TRIM(2);
	-- Trim last element
	nested_table.TRIM;
	DBMS_OUTPUT.PUT_LINE('nested_table.LAST = '||nested_table.LAST);
END;

-- Modify script ch15_1a.sql, used in Exercise 15.1.1. Instead of using an associative array, use a nested table. (ROSENZWEIG y RAKHIMOV, 2009, 331).



DECLARE
	CURSOR course_cur IS
		SELECT description
			FROM course;
	TYPE course_type IS TABLE OF course.description%TYPE;
	course_tab course_type := course_type();
	v_counter INTEGER := 0;
BEGIN
	FOR course_rec IN course_cur LOOP
		v_counter := v_counter + 1;
		course_tab.EXTEND;
		course_tab(v_counter) := course_rec.description;
		DBMS_OUTPUT.PUT_LINE('course_tab('|| v_counter || ')=' || course_tab(v_counter));
	END LOOP;
		
END;


-- Ejemplo, uso de varray, modificado(ROSENZWEIG y RAKHIMOV, 2009, 336).

DECLARE
	CURSOR name_cur IS
		SELECT last_name
			FROM student
			WHERE rownum <= 12;
	TYPE last_name_type IS VARRAY(12) OF student.last_name%TYPE;
	last_name_varray last_name_type := last_name_type();
	v_counter INTEGER := 0;
BEGIN
	FOR name_rec IN name_cur LOOP
		v_counter := v_counter + 1;
		last_name_varray.EXTEND;
		last_name_varray(v_counter) := name_rec.last_name;
		DBMS_OUTPUT.PUT_LINE ('last_name('||v_counter||'): '|| last_name_varray(v_counter));
	END LOOP;
	DBMS_OUTPUT.PUT_LINE ('varray.LIMIT = '|| last_name_varray.LIMIT);
	DBMS_OUTPUT.PUT_LINE ('varray.FIRST = '|| last_name_varray.FIRST);
END;
.
/
-- �Podemos usar desde posici�n 0?

DECLARE
	CURSOR name_cur IS
		SELECT last_name
			FROM student
			WHERE rownum <= 12;
	TYPE last_name_type IS VARRAY(13) OF student.last_name%TYPE;
	last_name_varray last_name_type := last_name_type();
	v_counter INTEGER := 0;
BEGIN
	last_name_varray.EXTEND;
		last_name_varray(0) := 'CORTES';

	FOR name_rec IN name_cur LOOP
		v_counter := v_counter + 1;
		last_name_varray.EXTEND;
		last_name_varray(v_counter) := name_rec.last_name;
		DBMS_OUTPUT.PUT_LINE ('last_name('||v_counter||'): '|| last_name_varray(v_counter));
	END LOOP;
	DBMS_OUTPUT.PUT_LINE ('varray.LIMIT = '|| last_name_varray.LIMIT);
	DBMS_OUTPUT.PUT_LINE ('varray.FIRST = '|| last_name_varray.FIRST);
END;
.
/

-- Ejemplo, uso de multilevel collections(ROSENZWEIG y RAKHIMOV, 2009, 343).


DECLARE
	TYPE varray_type1 IS VARRAY(4) OF INTEGER;
	TYPE varray_type2 IS VARRAY(3) OF varray_type1;
	varray1 varray_type1 := varray_type1(2, 4, 6, 8);
	varray2 varray_type2 := varray_type2(varray1);
BEGIN
	DBMS_OUTPUT.PUT_LINE ('Varray of integers');
	FOR i IN 1..4 LOOP
		DBMS_OUTPUT.PUT_LINE ('varray1('||i||'): '||varray1(i));
	END LOOP;
	varray2.EXTEND;
	varray2(2) := varray_type1(1, 3, 5, 7);
	DBMS_OUTPUT.PUT_LINE (chr(10)||'Varray of varrays of integers');
	FOR i IN 1..2 LOOP
		FOR j IN 1..4 LOOP
			DBMS_OUTPUT.PUT_LINE('varray2('||i||')('||j||'): '||varray2(i)(j));
		END LOOP;
	END LOOP;
END;

.
/


spool OFF;
